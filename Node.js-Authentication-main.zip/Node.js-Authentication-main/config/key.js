module.exports = {
    MongoURI: "mongodb+srv://mrinalgupta7890:EqeL0wMr6fZsKcuX@cluster0.qhwqdzj.mongodb.net/"
}
